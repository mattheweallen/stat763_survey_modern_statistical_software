library(shiny)
library(DT)

ui <- fluidPage(
    title = 'DataTables Information',
    h1('A client-side table'),
    fluidRow(
        column(6, DT::dataTableOutput('x1')),
        column(6, plotOutput('x2', height = 500))
    ),
    fluidRow(
        p(class = 'text-center', downloadButton('x3', 'Download Filtered Data'))
    ),
)

server <- function(input, output, session) {
    
    # two columns of the mtcars data
    mtcars2 = mtcars[, c('hp', 'mpg')]
    
    # render the table (with row names)
    output$x1 = DT::renderDataTable(mtcars2, server = FALSE)
    
    # a scatterplot with certain points highlighted
    output$x2 = renderPlot({
        
        s1 = input$x1_rows_current  # rows on the current page
        s2 = input$x1_rows_all      # rows on all pages (after being filtered)
        
        par(mar = c(4, 4, 1, .1))
        plot(mtcars2, pch = 21)
        
        # solid dots (pch = 19) for current page
        if (length(s1)) {
            points(mtcars2[s1, , drop = FALSE], pch = 19, cex = 2)
        }
        
        # show red circles when performing searching
        if (length(s2) > 0 && length(s2) < nrow(mtcars2)) {
            points(mtcars2[s2, , drop = FALSE], pch = 21, cex = 3, col = 'red')
        }
        
        # dynamically change the legend text
        s = input$x1_search
        txt = if (is.null(s) || s == '') 'Filtered data' else {
            sprintf('Data matching "%s"', s)
        }
        
        legend(
            'topright', c('Original data', 'Data on current page', txt),
            pch = c(21, 19, 21), pt.cex = c(1, 2, 3), col = c(1, 1, 2),
            y.intersp = 2, bty = 'n'
        )
        
    })
    
    # download the filtered data
    output$x3 = downloadHandler('mtcars-filtered.csv', content = function(file) {
        s = input$x1_rows_all
        write.csv(mtcars2[s, , drop = FALSE], file)
    })
}

shinyApp(ui = ui, server = server)
